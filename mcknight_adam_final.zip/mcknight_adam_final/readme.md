# McKnight Adam Final
## Final Project Documentation

This project contains the following features...
1. The ability to create a Light and Show it's details.
2. Calculate the total number of watts your home will use, based upon the average wattage of Christmas Lights and lights needed.
3. Export this data to a binary file. **Note:** The Location will be listed in program's output, as it may be different per-computer.
4. The ability to exit the program without using control/command + c

Test data and screenshots were provided in the root of this directory.

