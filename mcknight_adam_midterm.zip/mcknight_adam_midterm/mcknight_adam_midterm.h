﻿// mcknight_adam_midterm.h : Include file for standard system include files,
// or project specific include files.

#pragma once

#include <iostream>
#include <algorithm>
#include <cstring> 


// TODO: Reference additional headers your program requires here.
