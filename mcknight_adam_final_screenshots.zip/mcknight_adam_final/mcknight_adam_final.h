﻿#pragma once

#include <iostream>
#include <cmath>
#include <fstream>
