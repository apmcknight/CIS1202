﻿// mcknight_adam_week13.h : Include file for standard system include files,
// or project specific include files.

#pragma once

#include <iostream>
